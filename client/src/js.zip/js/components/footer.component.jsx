import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>
        <ul>
          <li>Document management system</li>
        </ul>
      </footer>
    );
  }
}
export default Footer;