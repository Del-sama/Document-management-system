import React, { Component } from 'react';

const AllDocs = () => {
  return (
    <div>
      <h2>First awesome doc</h2>
      <p>Add this doc</p>
    </div>
  )
}